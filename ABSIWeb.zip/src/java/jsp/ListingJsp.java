package jsp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jsp.data.UserJsp;

public class ListingJsp extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<UserJsp> users = null;
		try {
			users = getUsers(request);
		} catch (Exception e) {
			throw new ServletException(e.getMessage());
		}
		request.setAttribute("users", users);
		request.getRequestDispatcher("/WEB-INF/jsp/listing.jsp").forward(request, response);
	}

	private ArrayList<UserJsp> getUsers(HttpServletRequest request) throws Exception {
		Class.forName("org.apache.derby.jdbc.ClientDriver");
		Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/absidb", "absi", "absi");
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM SYSUSER");

		ArrayList<UserJsp> results = new ArrayList<UserJsp>();
		while (rs.next()) {
			String username = rs.getString("username");
			String password = rs.getString("password");
			String url = "http://" + request.getServerName()
					+ ":"
					+ request.getServerPort()
					+ "/"
					+ request.getContextPath() 
					+ "/EditJsp?username="
					+ username;
			UserJsp user = new UserJsp(username, password, url);
			results.add(user);
		}
		return results;
	}
}
