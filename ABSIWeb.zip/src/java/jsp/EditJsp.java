package jsp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EditJsp extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		String username = request.getParameter("username");
		String password = null;
		String label = "Edit";
                
		if (username == null || username.equals(null)) {
			username = "";
			label = "Add";
		} else {
			try {
				password = this.getPassword(username);
			} catch (Exception e) {
				throw new ServletException(e.getMessage());
			}
		}
		if (password == null || password.equals(null)) {
			password = "";
		}
		request.setAttribute("username", username);
		request.setAttribute("password", password);
		request.setAttribute("label", label);
		request.getRequestDispatcher("/WEB-INF/jsp/edit.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			this.insertOrUpdate(request);
		} catch (Exception e) {
			throw new ServletException(e.getMessage());
		}
		response.sendRedirect("http://"
				+ request.getServerName()
				+ ":"
				+ request.getServerPort()
				+ request.getContextPath()
				+ "/ListingJsp");
	}

	private String getPassword(String username) throws Exception {
		Class.forName("org.apache.derby.jdbc.ClientDriver");
		Connection conn = DriverManager.getConnection(
				"jdbc:derby://localhost:1527/absidb",
				"absi",
				"absi");
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM SYSUSER WHERE username = '"
				+ username + "'");
		rs.next();
		return rs.getString("password");
	}

	private void insertOrUpdate(HttpServletRequest request) throws Exception {
		Class.forName("org.apache.derby.jdbc.ClientDriver");
		Connection conn = DriverManager.getConnection(
				"jdbc:derby://localhost:1527/absidb",
				"absi",
				"absi");
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM SYSUSER WHERE username = '"
				+ request.getParameter("username") + "'");
		if (rs.next()) {
			PreparedStatement insert = conn.prepareStatement(
					"UPDATE SYSUSER SET password = ? WHERE username = ?");
			insert.setString(1, request.getParameter("password"));
			insert.setString(2, request.getParameter("username"));
			insert.execute();
		} else {
			PreparedStatement insert = conn.prepareStatement("INSERT INTO SYSUSER (username, password) VALUES (?,?)");
			insert.setString(1, request.getParameter("username"));
			insert.setString(2, request.getParameter("password"));
			insert.execute();
		}
	}
        
}
