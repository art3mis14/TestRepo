package jsp.data;

public class UserJsp {
	public final String username;
	public final String password;
	public final String url;
	
	public UserJsp(String username, String password, String url) {
		this.username = username;
		this.password = password;
		this.url = url;
	}
}
