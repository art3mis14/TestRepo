package sessions;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class YourName extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		HttpSession session = request.getSession(true);
		String name = (String) session.getAttribute("username");
		if (name == null) {
			name = "Stranger";
		}
		try (PrintWriter out = response.getWriter()) {
			/* TODO output your page here. You may use following sample code. */
			out.println("<!DOCTYPE html>");
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Servlet YourName</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("<h1>Hello " + name + "</h1>");
			out.println("<form method=\"post\" action=\"/ABSIWeb/YourName\">");
			out.println("<h6>My name is</h6>");
			out.println("<input type=\"text\" name=\"username\"/>");
			out.println("<button type=\"submit\">submit</button>");
			out.println("</form>");
			out.println("</body>");
			out.println("</html>");
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		session.setAttribute("username", request.getParameter("username"));
		response.sendRedirect("http://localhost:8080/ABSIWeb/YourName");
	}
}
