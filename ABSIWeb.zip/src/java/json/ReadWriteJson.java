package json;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import org.json.JSONArray;
import org.json.JSONObject;

public class ReadWriteJson {

	public static final String json
			/*= "["
			+ "	{"
			+ "		\"username\": \"jose\","
			+ "		\"password\": \"rizal\""
			+ "	},"
			+ "	{"
			+ "		\"username\": \"andres\","
			+ "		\"password\": \"bonifacio\""
			+ "	}"
			+ "]";
                        */
                        
                        = " {"
                        + "    \"users\" :["
                        + "         {"
                        + "             \"username\": \"jose\","
                        + "             \"password\": \"rizal\""
                        + "         },"
                        + "         {"
                        + "             \"username\": \"andres\","
                        + "             \"password\": \"bonifacio\""
                        + "         }"
                        + "     ],"
                        + "     \"roles\" :["   
                        + "         \"Admin\","
                        + "         \"SuperAdmin\","
                        + "         \"OrdinaryUser\","
                        + "         \"GodMode\""
                        + "    ]"
                        + " }";

	public static void main(String args[]) throws FileNotFoundException, IOException {
            
                File in = new File("C:\\Users\\ABSI.ABSI-E470-08\\Desktop\\JAVA_Training\\Source Code\\ABSIWeb\\ABSIWeb\\src\\java\\json\\UserList.json");
                FileReader fr = new FileReader(in);
                BufferedReader br = new BufferedReader(fr);
                String line = br.readLine();
                String content = line;
                while(line != null){
                    line = br.readLine();
                    content += line;
                }
		// reading
                //JSONObject data = new JSONObject(ReadWriteJson.json);
                JSONObject data = new JSONObject(content);
                JSONArray users = data.getJSONArray("users"); 
                JSONArray roles = data.getJSONArray("roles"); 
                
                for (int i = 0; i < users.length(); i++ ) {
			JSONObject u = users.getJSONObject(i);
			System.out.println(u.getString("username"));
			System.out.println(u.getString("password"));
		}
                
                for (int i = 0; i < roles.length(); i++ ) {
			String role = roles.getString(i);
			System.out.println(role);
		}
                
                // writing
		JSONObject gabby = new JSONObject();
		gabby.put("username", "gabriela");
		gabby.put("password", "silang");

		//JSONArray newUsers = new JSONArray();
		users.put(gabby);
		//System.out.println(newUsers);
                System.out.println(data);
                
                File out = new File("C:\\Users\\ABSI.ABSI-E470-08\\Desktop\\JAVA_Training\\Source Code\\ABSIWeb\\ABSIWeb\\src\\java\\json\\UserList_out.json");
                FileWriter fw = new FileWriter(out);
                PrintWriter pw = new PrintWriter(fw);
                pw.print(data);
                pw.close();
                
                /*JSONArray users = new JSONArray(ReadWriteJson.json);
		for (int i = 0; i < users.length(); i++ ) {
			JSONObject u = users.getJSONObject(i);
			System.out.println(u.getString("username"));
			System.out.println(u.getString("password"));
		}
		// writing
		JSONObject gabby = new JSONObject();
		gabby.put("username", "gabriela");
		gabby.put("password", "silang");

		JSONArray newUsers = new JSONArray();
		newUsers.put(gabby);
		System.out.println(newUsers);*/
	}
}
