package crud;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Edit extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		String username = request.getParameter("username");
		String password = null;
		String label = "Edit";
		if (username == null || username.equals(null)) {
			username = "";
			label = "Add";
		} else {
			try {
				password = this.getPassword(username);
                                System.out.println("pass=>"+password);
                                
			} catch (Exception e) {
				throw new ServletException(e.getMessage());
			}
		}
		if (password == null || password.equals(null)) {
			password = "";
		}
		// ________
		try (PrintWriter out = response.getWriter()) {
			out.println("<html>");
			out.println("<head>");
                        out.println("<link rel=\"stylesheet\" href=\"/ABSIWeb/css/bootstrap.min.css\">");
                        out.println("<script src=\"/ABSIWeb/js/bootstrap.min.js\"></script>");
			out.println("<title>" + label + " Page</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("<h1>" + label + " Page</h1>");
			out.println("<form method=\"POST\" action=\""
					+ request.getContextPath() + "/Edit\">");
			out.println("<label>username</label>");
			out.println("<br>");
			out.println("<input type=\"text\" name=\"username\" value=\"" + username + "\"/>");
			out.println("<br>");
			out.println("<label>password</label>");
			out.println("<br>");
			out.println("<input type=\"text\" name=\"password\" value=\"" + password + "\"/>");
			out.println("<br>");
			out.println("<button type=\"submit\">submit</button>");
			out.println("</form>");
			out.println("</body>");
			out.println("</html>");
			out.println("");
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			this.insertOrUpdate(request);
		} catch (Exception e) {
			throw new ServletException(e.getMessage());
		}
		response.sendRedirect("http://"
				+ request.getServerName()
				+ ":"
				+ request.getServerPort()
				+ request.getContextPath()
				+ "/Listing");
	}

	private String getPassword(String username) throws Exception {
		Class.forName("org.apache.derby.jdbc.ClientDriver");
		Connection conn = DriverManager.getConnection(
				"jdbc:derby://localhost:1527/absidb",
				"absi",
				"absi");
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM SYSUSER WHERE username = '"
				+ username + "'");
		rs.next();
		return rs.getString("password");
	}

	private void insertOrUpdate(HttpServletRequest request) throws Exception {
		Class.forName("org.apache.derby.jdbc.ClientDriver");
		Connection conn = DriverManager.getConnection(
				"jdbc:derby://localhost:1527/absidb",
				"absi",
				"absi");
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM SYSUSER WHERE username = '"
				+ request.getParameter("username") + "'");
		if (rs.next()) {
			PreparedStatement insert = conn.prepareStatement(
					"UPDATE SYSUSER SET password = ? WHERE username = ?");
			insert.setString(1, request.getParameter("password"));
			insert.setString(2, request.getParameter("username"));
			insert.execute();
		} else {
			PreparedStatement insert = conn.prepareStatement("INSERT INTO SYSUSER (username, password) VALUES (?,?)");
			insert.setString(1, request.getParameter("username"));
			insert.setString(2, request.getParameter("password"));
			insert.execute();
		}
	}
}
