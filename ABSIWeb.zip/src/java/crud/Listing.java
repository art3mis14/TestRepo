package crud;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Listing extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ResultSet rs = null;
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");
			Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/absidb", "absi", "absi");
			Statement st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM SYSUSER");
		} catch (Exception e) {
			throw new ServletException(e.getMessage());
		}
		response.setContentType("text/html;charset=UTF-8");
		try (PrintWriter out = response.getWriter()) {
			/* TODO output your page here. You may use following sample code. */
			out.println("<html>");
			out.println("<head>");
                        out.println("<link rel=\"stylesheet\" href=\"/ABSIWeb/css/bootstrap.min.css\">");
                        out.println("<script src=\"/ABSIWeb/js/bootstrap.min.js\"></script>");
			out.println("<title>Listing Page</title>");
			out.println("<style>");
			out.println("table {");
			out.println("border-collapse: collapse;");
			out.println("}");
			out.println("table, th, td {");
			out.println("border: 1px solid black;");
			out.println("}");
			out.println("</style>");
			out.println("</head>");
			out.println("<body>");
			out.println("<h1>Listing Page</h1>");
			out.println("<table>");
			out.println("<thead>");
			out.println("<th>Username</th>");
			out.println("<th>Password</th>");
			out.println("</thead>");
			out.println("<tbody>");
			try {
				while (rs.next()) {
					out.println("<tr>");
					String username = rs.getString("username");
					String password = rs.getString("password");
					out.println("<td><a href=\""
							+ request.getContextPath()
							+ "/Edit?username="
							+ username
							+ "\">"
							+ username
							+ "</a></td>");
					out.println("<td>" + password + "</td>");
					out.println("</tr>");
				}
			} catch (Exception e) {
				throw new ServletException(e.getMessage());
			}
			out.println("</tbody>");
			out.println("</table>");
			out.println("<br>");
			out.println("<a href=\"http://"
					+ request.getServerName()
					+ ":"
					+ request.getServerPort()
					+ "/"
					+ request.getContextPath()
					+ "/Edit\">Add User</a>");
			out.println("</body>");
			out.println("</html>");
		}
	}
}
